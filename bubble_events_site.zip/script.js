function startQuiz() {
    alert("כאן יהיה שאלון הרכבת האירוע!");
}
